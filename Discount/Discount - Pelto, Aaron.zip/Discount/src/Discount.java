// This program calculates the sale price of an
// item that is regularly priced at $59, with
// a 20 percent discount subtracted.

import javax.swing.*;
import java.util.Scanner;

public class Discount {
    static final double discount = 0.20;

    public static void main(String[] args) {

        //Variables to hold the regular price, the
        // amount of a discount, and the sale price.
        String input;
        double regularPrice = 59.0;
        double salePrice;
        double amountDiscount;

        // Create a Scanner object to read input
        Scanner keyboard = new Scanner(System.in);

        // Get the regular price
        input = JOptionPane.showInputDialog("Enter regular price: ");
        regularPrice = Double.parseDouble(input);

        // Calculate the amount of a 20% discount.
        amountDiscount = regularPrice * discount;

        // Calculate the sale price by subtracting
        // the discount from the regular price.
        salePrice = regularPrice - amountDiscount;

        // Display the results.
        JOptionPane.showMessageDialog(null, "Regular price: $" + regularPrice);
        JOptionPane.showMessageDialog(null, "Discount amount: $" + amountDiscount);
        JOptionPane.showMessageDialog(null, "Sale price: $" + salePrice);
    }
}